# Depression Detection Using ML Algorithms
This project used data from social media networks to explore various methods of early detection of MDDs based on machine learning. We performed a thorough analysis of the dataset to characterize the subjects’ behavior based on different aspects of their PHQ9 question answering, textual inputs, Python code for Depression Detection using multiple machine learning algorithms and Twitter dataset for detecting depression also from sentiments

### Running the Application  

Following steps should be followed to run the app:  

> 1. Install all libraries ```$ pip install -r requirements.txt```  
> 2. Run the application ```$ python server.py```  
> 3. In Browser open URL localhost: 5987  
> 4. Login Using:
>    - Username : ```admin```  
>    - Password : ```admin```  

\* _Note : Username and password can be chnaged in server.py file_
